Files:
england_ct_2001.shp
england_ct_2001.shx
england_ct_2001.dbf
england_ct_2001.prj

Areas:
Cornwall And Isles Of Scilly

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.